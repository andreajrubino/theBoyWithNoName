package logic;

public class Weapon extends Collectible{
	public Weapon(String name, int i, int j){
		super(name,i,j);
	}
}